import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.text.DateFormat;
import java.util.*;
import javax.naming.Name;
import javax.swing.*;
import java.lang.Number;
import java.util.Date;
import java.text.SimpleDateFormat;


/**
 * 
 * CSCU9T4 Java strings and files exercise.
 *
 */
public class FilesInOut {

    public static void main(String[] args) throws Exception {
        // Replace this with statements to set the file name (input) and file name (output).
        FileReader reader = new FileReader("C:\\Users\\halle\\Desktop\\CSCUT4Practical2-main\\CSCUT4Practical2-main\\inputm.txt");
        PrintWriter writer = new PrintWriter("C:\\Users\\halle\\Desktop\\CSCUT4Practical2-main\\CSCUT4Practical2-main\\output.txt");
        
        // Initially it will be easier to hardcode suitable file names.
        // Set up a new Scanner to read the input file.

        char[] Name;
        char[] temp;

        Scanner sc = new Scanner(reader);

        while (sc.hasNextLine())
        {
            Name = sc.nextLine().toCharArray();
            Name[0] = Character.toTitleCase(Name[0]);
            temp = new char[Name.length + 3];
            for(int i = 0; i < Name.length; i++)
            {
                temp[i] = Name[i];
            }

            for(int i = 0; i < Name.length; i++)
            {
                 if (Name[i] == ' ')
                {
                    temp[i+1] = Character.toTitleCase(Name[i+1]);

                    if(Name[i+2] == ' ')
                    {
                        for(int j = temp.length - 1; j > i + 2; j--)
                        {
                            temp[j] = temp[j - 1];
                        }
                        temp[i+2] = '.';

                    }

                    if(temp[i] == '0' || temp[i] == '1' || temp[i] == '2' || temp[i] == '3' || temp[i] == '4'
                            || temp[i] == '5' || temp[i] == '6' || temp[i] == '7' || temp[i] == '8' || temp[i] == '9')
                    {

                    }
                    Name = temp;
                }

            }

            System.out.println(Name); //prints the formatted Name
            System.out.println(" "); //prints an empty line

        }

    }


        // Processing line by line would be sensible here.
        // Initially, echo the text to System.out to check you are reading correctly.
        // Then add code to modify the text to the output format.

        // Set up a new PrintWriter to write the output file.
        // Add suitable code into the above processing (because you need to do this line by line also.
        // That is, read a line, write a line, loop.

        // Finally, add code to read the filenames as arguments from the command line.


    // main


} // FilesInOut
