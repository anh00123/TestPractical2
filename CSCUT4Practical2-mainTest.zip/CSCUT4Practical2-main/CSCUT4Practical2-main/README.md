# CSCUT4Practical2
The starter code for practical exercise 2

This project is not specific to any IDE nor dependency management.  
It is just the bare .java file and some test csv files. You are free to use any IDE of your choice.
